$('.teams-section .Show').click(function() {
    $('.teams-section #target').show(200);
    $('.teams-section .Show').hide(0);
    $('.teams-section .Hide').show(0);
});
$('.teams-section .Hide').click(function() {
    $('.teams-section #target').hide(500);
    $('.teams-section .Show').show(0);
    $('.teams-section .Hide').hide(0);
});

$('.teams-section .Show2').click(function() {
    $('.teams-section #target2').show(200);
    $('.teams-section .Show2').hide(0);
    $('.teams-section .Hide2').show(0);
});
$('.teams-section .Hide2').click(function() {
    $('.teams-section #target2').hide(500);
    $('.teams-section .Show2').show(0);
    $('.teams-section .Hide2').hide(0);
});

$('.teams-section .Show3').click(function() {
    $('.teams-section #target3').show(200);
    $('.teams-section .Show3').hide(0);
    $('.teams-section .Hide3').show(0);
});
$('.teams-section .Hide3').click(function() {
    $('.teams-section #target3').hide(500);
    $('.teams-section .Show3').show(0);
    $('.teams-section .Hide3').hide(0);
});


$('.teams-section .Show4').click(function() {
    $('.teams-section #target4').show(200);
    $('.teams-section .Show4').hide(0);
    $('.teams-section .Hide4').show(0);
});
$('.teams-section .Hide4').click(function() {
    $('.teams-section #target4').hide(500);
    $('.teams-section .Show4').show(0);
    $('.teams-section .Hide4').hide(0);
});


$('.teams-section .Show5').click(function() {
    $('.teams-section #target5').show(200);
    $('.teams-section .Show5').hide(0);
    $('.teams-section .Hide5').show(0);
});
$('.teams-section .Hide5').click(function() {
    $('.teams-section #target5').hide(500);
    $('.teams-section .Show5').show(0);
    $('.teams-section .Hide5').hide(0);
});



$('.teams-section .Show6').click(function() {
    $('.teams-section #target6').show(200);
    $('.teams-section .Show6').hide(0);
    $('.teams-section .Hide6').show(0);
});
$('.teams-section .Hide6').click(function() {
    $('.teams-section #target6').hide(500);
    $('.teams-section .Show6').show(0);
    $('.teams-section .Hide6').hide(0);
});

// our-teams-page


// $('.teams-section .Show11').click(function() {
//     $('.teams-section #target11').show(200);
//     $('.teams-section .Show11').hide(0);
//     $('.teams-section .Hide11').show(0);
// });
// $('.teams-section .Hide11').click(function() {
//     $('.teams-section #target11').hide(500);
//     $('.teams-section .Show11').show(0);
//     $('.teams-section .Hide11').hide(0);
// });


// $('.teams-section .Show12').click(function() {
//     $('.teams-section #target12').show(200);
//     $('.teams-section .Show12').hide(0);
//     $('.teams-section .Hide12').show(0);
// });
// $('.teams-section .Hide12').click(function() {
//     $('.teams-section #target12').hide(500);
//     $('.teams-section .Show12').show(0);
//     $('.teams-section .Hide12').hide(0);
// });



// $('.teams-section .Show13').click(function() {
//     $('.teams-section #target13').show(200);
//     $('.our-teams-page .Show13').hide(0);
//     $('.our-teams-page .Hide13').show(0);
// });
// $('.teams-section .Hide13').click(function() {
//     $('.teams-section #target13').hide(500);
//     $('.teams-section .Show13').show(0);
//     $('.teams-section .Hide13').hide(0);
// });


// $('.our-teams-page .Show14').click(function() {
//     $('.our-teams-page #target14').show(200);
//     $('.our-teams-page .Show14').hide(0);
//     $('.our-teams-page .Hide14').show(0);
// });
// $('.our-teams-page .Hide14').click(function() {
//     $('.our-teams-page #target14').hide(500);
//     $('.our-teams-page .Show14').show(0);
//     $('.our-teams-page .Hide14').hide(0);
// });


// $('.our-teams-page .Show15').click(function() {
//     $('.our-teams-page #target15').show(200);
//     $('.our-teams-page .Show15').hide(0);
//     $('.our-teams-page .Hide15').show(0);
// });
// $('.our-teams-page .Hide15').click(function() {
//     $('.our-teams-page #target15').hide(500);
//     $('.our-teams-page .Show15').show(0);
//     $('.our-teams-page .Hide15').hide(0);
// });


$('.our-teams-page .Show16').click(function() {
    $('.our-teams-page #target16').show(200);
    $('.our-teams-page .Show16').hide(0);
    $('.our-teams-page .Hide16').show(0);
});
$('.our-teams-page .Hide16').click(function() {
    $('.our-teams-page #target16').hide(500);
    $('.our-teams-page .Show16').show(0);
    $('.our-teams-page .Hide16').hide(0);
});